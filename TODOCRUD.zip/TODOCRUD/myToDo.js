// Add Todo
function addTodo() {
    const input = document.getElementById('todoInput');
    const todoText = input.value.trim();

    if (todoText === '') {
        alert('Please enter a TODO');
        return;
    }

    const li = document.createElement('li');
    li.innerHTML = `
        ${todoText}
        <button onclick="editTodo(this)">Edit</button>
        <button onclick="deleteTodo(this)">Delete</button>
    `;
    document.getElementById('todoList').appendChild(li);

    input.value = '';
}

function editTodo(x) {
    const li = x.parentElement;
    const newTodoTask = prompt('Edit TODO:', li.firstChild.textContent.trim());

    if (newTodoTask !== null && newTodoTask.trim() !== '') {
        li.firstChild.textContent = newTodoTask;
    }
}

// Function to delete a TODO
function deleteTodo(x) {
    const li = x.parentElement;
    if (confirm('Are you sure you want to delete this task?')) {
        li.remove();
    }
    
}

